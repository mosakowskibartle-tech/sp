# 🚀 Развёртывание на REG.RU — Кафе «Соль и Перец»

## Данные вашего хостинга
- **Сервер**: server249.hosting.reg.ru:1500
- **IP**: 31.31.196.115
- **БД**: u3471617_solperets (MySQL)
- **Пользователь БД**: u3471617_solperets

---

## ШАГ 1: Создать таблицы в MySQL

1. Войдите в **phpMyAdmin** на REG.RU (в панели управления хостингом)
2. Выберите базу данных **u3471617_solperets**
3. Нажмите вкладку **«SQL»**
4. Вставьте содержимое файла **`database_mysql.sql`** и нажмите **«Выполнить»**

---

## ШАГ 2: Собрать проект

На вашем компьютере (или через SSH):
```bash
npm install
npm run build
```

---

## ШАГ 3: Загрузить файлы на сервер

### Через FTP (FileZilla / WinSCP):
```
Хост:     server249.hosting.reg.ru  (или 31.31.196.115)
Порт:     21 (FTP) или 22 (SFTP)
Логин:    ваш логин REG.RU
Пароль:   ваш пароль REG.RU
```

Загрузите в папку `public_html` (или `www`):
```
public_html/
├── dist/           ← содержимое папки dist/ после npm run build
├── server.js       ← главный сервер
├── package.json    ← зависимости
├── .env            ← переменные окружения
├── ecosystem.config.cjs  ← конфиг PM2
└── node_modules/   ← установить на сервере через npm install
```

### Через SSH (если есть доступ):
```bash
ssh u3471617@server249.hosting.reg.ru -p 1500
cd ~/public_html
# Загрузить файлы через scp или git
```

---

## ШАГ 4: Установить зависимости на сервере

```bash
cd ~/public_html
npm install --production
```

---

## ШАГ 5: Запустить сервер

### Через PM2 (рекомендуется):
```bash
npm install -g pm2
pm2 start ecosystem.config.cjs
pm2 save
pm2 startup  # автозапуск при перезагрузке
```

### Напрямую (для теста):
```bash
node server.js
```

---

## ШАГ 6: Настроить .htaccess (если Apache)

Создайте файл `public_html/.htaccess`:
```apache
RewriteEngine On
RewriteRule ^api/(.*)$ http://localhost:3000/api/$1 [P,L]
RewriteCond %{REQUEST_FILENAME} !-f
RewriteRule ^ /index.html [L]
```

Или если REG.RU даёт Node.js хостинг напрямую — .htaccess не нужен.

---

## ШАГ 7: Инициализировать БД через API

После запуска сервера вызовите:
```bash
curl -X POST https://ваш-домен.ru/api/migrate \
  -H "Content-Type: application/json" \
  -d '{"secret":"migrate2025"}'
```

Ответ должен быть: `{"ok":true,"message":"Все таблицы созданы!"}`

---

## ШАГ 8: Добавить меню

Войдите в **`/admin`** (пароль: `admin2025`) и добавьте блюда через интерфейс.

Или импортируйте данные из Supabase через phpMyAdmin.

---

## Настройка Telegram уведомлений

1. Откройте `/admin` → **«Настройки»**
2. Введите токен бота (от @BotFather)
3. Введите Chat ID (от @userinfobot)
4. Нажмите «Тест» — должно прийти сообщение

---

## Проверка работы

- Сайт: `http://31.31.196.115:3000` или `https://ваш-домен.ru`
- API: `http://31.31.196.115:3000/api/menu`
- Админка: `https://ваш-домен.ru/admin`

---

## Структура API (все работают на том же сервере)

| Метод | URL | Описание |
|-------|-----|----------|
| GET | /api/menu | Все блюда |
| POST | /api/menu | Добавить блюдо |
| PUT | /api/menu | Изменить блюдо |
| DELETE | /api/menu | Удалить блюдо |
| GET | /api/orders | Заказы |
| POST | /api/orders | Новый заказ |
| GET | /api/reservations | Брони |
| POST | /api/reservations | Новая бронь |
| GET | /api/reviews | Отзывы |
| POST | /api/reviews | Новый отзыв |
| GET | /api/banquets | Банкеты |
| POST | /api/banquets | Новый банкет |
| GET | /api/settings | Настройки |
| PUT | /api/settings | Изменить настройки |
| POST | /api/admin-auth | Авторизация |
| POST | /api/migrate | Создать таблицы |

---

## Если что-то не работает

```bash
# Логи PM2
pm2 logs sol-perec

# Перезапуск
pm2 restart sol-perec

# Статус
pm2 status

# Проверка MySQL
mysql -u u3471617_solperets -p u3471617_solperets
# Пароль: Qasderg17@&
SHOW TABLES;
```
