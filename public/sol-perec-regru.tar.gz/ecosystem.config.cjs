module.exports = {
  apps: [{
    name: 'sol-perec',
    script: 'server.js',
    instances: 1,
    exec_mode: 'fork',
    env: {
      NODE_ENV: 'production',
      PORT: 3000,
      DB_HOST: 'localhost',
      DB_PORT: '3306',
      DB_NAME: 'u3471617_solperets',
      DB_USER: 'u3471617_solperets',
      DB_PASSWORD: 'Qasderg17@&',
      ADMIN_PASSWORD: 'admin2025',
      MIGRATE_SECRET: 'migrate2025',
    },
    watch: false,
    max_memory_restart: '500M',
    log_date_format: 'YYYY-MM-DD HH:mm:ss',
    error_file: './logs/error.log',
    out_file: './logs/out.log',
    merge_logs: true,
    autorestart: true,
    restart_delay: 3000,
  }]
};
