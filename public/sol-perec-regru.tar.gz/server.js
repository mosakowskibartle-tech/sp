/**
 * server.js — Express production server for REG.RU shared hosting
 * MySQL2 + Node.js + React SPA
 *
 * Start:  node server.js
 * PM2:    pm2 start server.js --name sol-perec
 */

import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import mysql from 'mysql2/promise';

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3000;

// ── Middleware ─────────────────────────────────────────────────────────────────
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname, 'dist')));

// ── MySQL Pool ─────────────────────────────────────────────────────────────────
const pool = mysql.createPool({
  host:               process.env.DB_HOST     || 'localhost',
  port:               parseInt(process.env.DB_PORT || '3306'),
  database:           process.env.DB_NAME     || 'u3471617_solperets',
  user:               process.env.DB_USER     || 'u3471617_solperets',
  password:           process.env.DB_PASSWORD || 'Qasderg17@&',
  waitForConnections: true,
  connectionLimit:    10,
  charset:            'utf8mb4',
});

// Test connection
pool.query('SELECT 1')
  .then(() => console.log('✅ MySQL connected'))
  .catch(e => console.error('❌ MySQL connection failed:', e.message));

// ── Helpers ────────────────────────────────────────────────────────────────────
async function q(sql, params = []) {
  const [rows] = await pool.execute(sql, params);
  return rows;
}

async function getTelegram() {
  try {
    const rows = await q("SELECT `key`, `value` FROM settings WHERE `key` IN ('telegram_bot_token','telegram_chat_id')");
    const s = {};
    rows.forEach(r => { s[r.key] = r.value; });
    return {
      token:  s.telegram_bot_token  || process.env.TELEGRAM_BOT_TOKEN  || '',
      chatId: s.telegram_chat_id    || process.env.TELEGRAM_CHAT_ID    || '',
    };
  } catch { return { token: '', chatId: '' }; }
}

async function sendTelegram(text) {
  try {
    const { token, chatId } = await getTelegram();
    if (!token || !chatId) return;
    await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: chatId, text, parse_mode: 'HTML' }),
    });
  } catch (e) { console.error('Telegram error:', e.message); }
}

function wrap(fn) {
  return async (req, res) => {
    try { await fn(req, res); }
    catch (e) {
      console.error(e);
      res.status(500).json({ error: e.message });
    }
  };
}

// ── MENU ──────────────────────────────────────────────────────────────────────
app.get('/api/menu', wrap(async (req, res) => {
  const { category, bar } = req.query;
  let sql = 'SELECT * FROM menu_items WHERE is_active = 1';
  const params = [];
  if (category) { sql += ' AND category = ?'; params.push(category); }
  if (bar === 'true')  { sql += ' AND is_bar = 1'; }
  if (bar === 'false') { sql += ' AND is_bar = 0'; }
  sql += ' ORDER BY sort_order ASC, id ASC';
  const rows = await q(sql, params);
  res.json(rows.map(r => ({
    ...r,
    is_active: !!r.is_active, is_bar: !!r.is_bar, is_special: !!r.is_special,
    is_gluten_free: !!r.is_gluten_free, is_lactose_free: !!r.is_lactose_free,
  })));
}));

app.post('/api/menu', wrap(async (req, res) => {
  const d = req.body;
  const [result] = await pool.execute(
    `INSERT INTO menu_items (name,description,price,category,image_url,calories,cook_time,
      is_gluten_free,is_lactose_free,is_bar,is_active,is_special,original_price,sort_order)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    [d.name, d.description||null, d.price, d.category, d.image_url||null,
     d.calories||null, d.cook_time||null,
     d.is_gluten_free?1:0, d.is_lactose_free?1:0, d.is_bar?1:0,
     d.is_active!==false?1:0, d.is_special?1:0,
     d.original_price||null, d.sort_order||0]
  );
  const [rows] = await pool.execute('SELECT * FROM menu_items WHERE id=?', [result.insertId]);
  res.status(201).json(rows[0]);
}));

app.put('/api/menu', wrap(async (req, res) => {
  const { id, ...d } = req.body;
  const fields = [];
  const vals = [];
  const boolFields = ['is_active','is_bar','is_special','is_gluten_free','is_lactose_free'];
  for (const [k, v] of Object.entries(d)) {
    fields.push(`\`${k}\` = ?`);
    vals.push(boolFields.includes(k) ? (v ? 1 : 0) : v);
  }
  await pool.execute(`UPDATE menu_items SET ${fields.join(',')} WHERE id=?`, [...vals, id]);
  const [rows] = await pool.execute('SELECT * FROM menu_items WHERE id=?', [id]);
  res.json(rows[0]);
}));

app.delete('/api/menu', wrap(async (req, res) => {
  await pool.execute('DELETE FROM menu_items WHERE id=?', [req.body.id]);
  res.json({ ok: true });
}));

// ── ORDERS ─────────────────────────────────────────────────────────────────────
app.get('/api/orders', wrap(async (req, res) => {
  const rows = await q('SELECT * FROM orders ORDER BY created_at DESC');
  res.json(rows.map(r => ({ ...r, items: JSON.parse(r.items || '[]') })));
}));

app.post('/api/orders', wrap(async (req, res) => {
  const d = req.body;
  const [result] = await pool.execute(
    `INSERT INTO orders (customer_name,customer_phone,delivery_address,comment,items,total_amount,status)
     VALUES (?,?,?,?,?,?,?)`,
    [d.customer_name, d.customer_phone, d.delivery_address||null,
     d.comment||null, JSON.stringify(d.items||[]), d.total_amount, d.status||'new']
  );
  const [rows] = await pool.execute('SELECT * FROM orders WHERE id=?', [result.insertId]);
  const order = { ...rows[0], items: JSON.parse(rows[0].items || '[]') };

  const itemsText = (d.items||[]).map(i => `• ${i.name} ×${i.quantity} = ${i.price*i.quantity}₽`).join('\n');
  await sendTelegram(
    `🍽 <b>Новый заказ #${result.insertId}</b>\n\n` +
    `👤 ${d.customer_name}\n📞 ${d.customer_phone}\n` +
    `📍 ${d.delivery_address || 'Самовывоз'}\n\n${itemsText}\n\n` +
    `💰 Итого: <b>${d.total_amount}₽</b>\n💬 ${d.comment||'Без комментария'}`
  );
  res.status(201).json(order);
}));

app.put('/api/orders', wrap(async (req, res) => {
  const { id, status } = req.body;
  await pool.execute('UPDATE orders SET status=? WHERE id=?', [status, id]);
  const [rows] = await pool.execute('SELECT * FROM orders WHERE id=?', [id]);
  res.json({ ...rows[0], items: JSON.parse(rows[0].items || '[]') });
}));

// ── RESERVATIONS ───────────────────────────────────────────────────────────────
app.get('/api/reservations', wrap(async (req, res) => {
  const { date } = req.query;
  let sql = 'SELECT * FROM reservations';
  const params = [];
  if (date) { sql += ' WHERE date = ?'; params.push(date); }
  sql += ' ORDER BY created_at DESC';
  res.json(await q(sql, params));
}));

app.post('/api/reservations', wrap(async (req, res) => {
  const d = req.body;
  const [result] = await pool.execute(
    `INSERT INTO reservations (guest_name,guest_phone,date,time,guests_count,table_number,status)
     VALUES (?,?,?,?,?,?,?)`,
    [d.guest_name, d.guest_phone, d.date, d.time,
     d.guests_count||2, d.table_number||null, d.status||'pending']
  );
  const [rows] = await pool.execute('SELECT * FROM reservations WHERE id=?', [result.insertId]);
  await sendTelegram(
    `📅 <b>Новая бронь стола</b>\n\n` +
    `👤 ${d.guest_name}\n📞 ${d.guest_phone}\n` +
    `🗓 ${d.date} в ${d.time}\n👥 Гостей: ${d.guests_count}\n` +
    `🪑 Стол: ${d.table_number||'любой'}`
  );
  res.status(201).json(rows[0]);
}));

app.put('/api/reservations', wrap(async (req, res) => {
  const { id, status } = req.body;
  await pool.execute('UPDATE reservations SET status=? WHERE id=?', [status, id]);
  const [rows] = await pool.execute('SELECT * FROM reservations WHERE id=?', [id]);
  res.json(rows[0]);
}));

app.delete('/api/reservations', wrap(async (req, res) => {
  await pool.execute('DELETE FROM reservations WHERE id=?', [req.body.id]);
  res.json({ ok: true });
}));

// ── REVIEWS ────────────────────────────────────────────────────────────────────
app.get('/api/reviews', wrap(async (req, res) => {
  const { all } = req.query;
  let sql = 'SELECT * FROM reviews';
  if (all !== 'true') sql += ' WHERE approved = 1';
  sql += ' ORDER BY created_at DESC';
  const rows = await q(sql);
  res.json(rows.map(r => ({ ...r, approved: !!r.approved })));
}));

app.post('/api/reviews', wrap(async (req, res) => {
  const { author_name, rating, text } = req.body;
  const [result] = await pool.execute(
    'INSERT INTO reviews (author_name,rating,text,approved) VALUES (?,?,?,0)',
    [author_name, rating, text]
  );
  const [rows] = await pool.execute('SELECT * FROM reviews WHERE id=?', [result.insertId]);
  res.status(201).json({ ...rows[0], approved: false });
}));

app.put('/api/reviews', wrap(async (req, res) => {
  const { id, approved } = req.body;
  await pool.execute('UPDATE reviews SET approved=? WHERE id=?', [approved?1:0, id]);
  const [rows] = await pool.execute('SELECT * FROM reviews WHERE id=?', [id]);
  res.json({ ...rows[0], approved: !!rows[0].approved });
}));

app.delete('/api/reviews', wrap(async (req, res) => {
  await pool.execute('DELETE FROM reviews WHERE id=?', [req.body.id]);
  res.json({ ok: true });
}));

// ── BANQUETS ───────────────────────────────────────────────────────────────────
app.get('/api/banquets', wrap(async (req, res) => {
  const rows = await q('SELECT * FROM banquet_requests ORDER BY created_at DESC');
  res.json(rows.map(r => ({ ...r, extra_services: JSON.parse(r.extra_services || '[]') })));
}));

app.post('/api/banquets', wrap(async (req, res) => {
  const d = req.body;
  const [result] = await pool.execute(
    `INSERT INTO banquet_requests
     (contact_name,contact_phone,event_type,package_name,guests_count,event_date,extra_services,estimated_total,comment,status)
     VALUES (?,?,?,?,?,?,?,?,?,?)`,
    [d.contact_name, d.contact_phone, d.event_type||null, d.package_name||null,
     d.guests_count||null, d.event_date||null,
     JSON.stringify(d.extra_services||[]),
     d.estimated_total||0, d.comment||null, d.status||'new']
  );
  const [rows] = await pool.execute('SELECT * FROM banquet_requests WHERE id=?', [result.insertId]);
  const svcs = (d.extra_services||[]).join(', ') || '—';
  await sendTelegram(
    `🎉 <b>Заявка на банкет</b>\n\n` +
    `👤 ${d.contact_name}\n📞 ${d.contact_phone}\n` +
    `🎊 Повод: ${d.event_type||'—'}\n📦 Пакет: ${d.package_name||'—'}\n` +
    `👥 Гостей: ${d.guests_count}\n📅 Дата: ${d.event_date}\n` +
    `💰 ~${d.estimated_total}₽\n🎁 Доп. услуги: ${svcs}\n💬 ${d.comment||'—'}`
  );
  res.status(201).json({ ...rows[0], extra_services: d.extra_services||[] });
}));

app.put('/api/banquets', wrap(async (req, res) => {
  const { id, status } = req.body;
  await pool.execute('UPDATE banquet_requests SET status=? WHERE id=?', [status, id]);
  const [rows] = await pool.execute('SELECT * FROM banquet_requests WHERE id=?', [id]);
  res.json({ ...rows[0], extra_services: JSON.parse(rows[0].extra_services||'[]') });
}));

// ── PROMOTIONS ─────────────────────────────────────────────────────────────────
app.get('/api/promotions', wrap(async (req, res) => {
  const { all } = req.query;
  let sql = 'SELECT * FROM promotions';
  if (all !== 'true') sql += ' WHERE is_active = 1';
  sql += ' ORDER BY sort_order ASC';
  const rows = await q(sql);
  res.json(rows.map(r => ({ ...r, is_active: !!r.is_active })));
}));

app.post('/api/promotions', wrap(async (req, res) => {
  const d = req.body;
  const [result] = await pool.execute(
    'INSERT INTO promotions (title,description,discount_text,expires_at,is_active,sort_order) VALUES (?,?,?,?,?,?)',
    [d.title, d.description||null, d.discount_text||null,
     d.expires_at||null, d.is_active?1:0, d.sort_order||0]
  );
  const [rows] = await pool.execute('SELECT * FROM promotions WHERE id=?', [result.insertId]);
  res.status(201).json({ ...rows[0], is_active: !!rows[0].is_active });
}));

app.put('/api/promotions', wrap(async (req, res) => {
  const { id, ...d } = req.body;
  await pool.execute(
    'UPDATE promotions SET title=?,description=?,discount_text=?,expires_at=?,is_active=?,sort_order=? WHERE id=?',
    [d.title, d.description||null, d.discount_text||null,
     d.expires_at||null, d.is_active?1:0, d.sort_order||0, id]
  );
  const [rows] = await pool.execute('SELECT * FROM promotions WHERE id=?', [id]);
  res.json({ ...rows[0], is_active: !!rows[0].is_active });
}));

app.delete('/api/promotions', wrap(async (req, res) => {
  await pool.execute('DELETE FROM promotions WHERE id=?', [req.body.id]);
  res.json({ ok: true });
}));

// ── GALLERY ────────────────────────────────────────────────────────────────────
app.get('/api/gallery', wrap(async (req, res) => {
  const { all } = req.query;
  let sql = 'SELECT * FROM gallery';
  if (all !== 'true') sql += ' WHERE is_active = 1';
  sql += ' ORDER BY sort_order ASC';
  const rows = await q(sql);
  res.json(rows.map(r => ({ ...r, is_active: !!r.is_active })));
}));

app.post('/api/gallery', wrap(async (req, res) => {
  const d = req.body;
  const [result] = await pool.execute(
    'INSERT INTO gallery (url,caption,category,sort_order,is_active) VALUES (?,?,?,?,?)',
    [d.url, d.caption||null, d.category||'general', d.sort_order||0, d.is_active?1:0]
  );
  const [rows] = await pool.execute('SELECT * FROM gallery WHERE id=?', [result.insertId]);
  res.status(201).json({ ...rows[0], is_active: !!rows[0].is_active });
}));

app.put('/api/gallery', wrap(async (req, res) => {
  const { id, ...d } = req.body;
  await pool.execute(
    'UPDATE gallery SET url=?,caption=?,category=?,sort_order=?,is_active=? WHERE id=?',
    [d.url, d.caption||null, d.category||'general', d.sort_order||0, d.is_active?1:0, id]
  );
  const [rows] = await pool.execute('SELECT * FROM gallery WHERE id=?', [id]);
  res.json({ ...rows[0], is_active: !!rows[0].is_active });
}));

app.delete('/api/gallery', wrap(async (req, res) => {
  await pool.execute('DELETE FROM gallery WHERE id=?', [req.body.id]);
  res.json({ ok: true });
}));

// ── SETTINGS ───────────────────────────────────────────────────────────────────
app.get('/api/settings', wrap(async (req, res) => {
  const rows = await q('SELECT `key`, `value` FROM settings');
  const obj = {};
  rows.forEach(r => { obj[r.key] = r.value; });
  res.json(obj);
}));

app.put('/api/settings', wrap(async (req, res) => {
  for (const [key, value] of Object.entries(req.body)) {
    await pool.execute(
      'INSERT INTO settings (`key`,`value`) VALUES (?,?) ON DUPLICATE KEY UPDATE `value`=?',
      [key, value, value]
    );
  }
  res.json({ ok: true });
}));

// ── ADMIN AUTH ─────────────────────────────────────────────────────────────────
app.post('/api/admin-auth', wrap(async (req, res) => {
  const { password } = req.body;
  const adminPass = process.env.ADMIN_PASSWORD || 'admin2025';
  if (password === adminPass) {
    return res.json({ ok: true, token: Buffer.from(`admin:${Date.now()}`).toString('base64') });
  }
  res.status(401).json({ error: 'Неверный пароль' });
}));

// ── MIGRATE (первый запуск) ────────────────────────────────────────────────────
app.post('/api/migrate', wrap(async (req, res) => {
  const { secret } = req.body;
  if (secret !== (process.env.MIGRATE_SECRET || 'migrate2025')) {
    return res.status(403).json({ error: 'Forbidden' });
  }

  const tables = [
    `CREATE TABLE IF NOT EXISTS menu_items (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(255) NOT NULL,
      description TEXT,
      price INT NOT NULL,
      category VARCHAR(100) NOT NULL,
      image_url TEXT,
      calories INT,
      cook_time INT,
      is_gluten_free TINYINT(1) DEFAULT 0,
      is_lactose_free TINYINT(1) DEFAULT 0,
      is_bar TINYINT(1) DEFAULT 0,
      is_active TINYINT(1) DEFAULT 1,
      is_special TINYINT(1) DEFAULT 0,
      original_price INT,
      sort_order INT DEFAULT 0,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    `CREATE TABLE IF NOT EXISTS orders (
      id INT AUTO_INCREMENT PRIMARY KEY,
      customer_name VARCHAR(255) NOT NULL,
      customer_phone VARCHAR(50) NOT NULL,
      delivery_address TEXT,
      comment TEXT,
      items JSON NOT NULL,
      total_amount INT NOT NULL,
      status VARCHAR(50) DEFAULT 'new',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    `CREATE TABLE IF NOT EXISTS reservations (
      id INT AUTO_INCREMENT PRIMARY KEY,
      guest_name VARCHAR(255) NOT NULL,
      guest_phone VARCHAR(50) NOT NULL,
      date VARCHAR(20) NOT NULL,
      time VARCHAR(10) NOT NULL,
      guests_count INT DEFAULT 2,
      table_number INT,
      status VARCHAR(50) DEFAULT 'pending',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    `CREATE TABLE IF NOT EXISTS reviews (
      id INT AUTO_INCREMENT PRIMARY KEY,
      author_name VARCHAR(255) NOT NULL,
      rating INT NOT NULL,
      text TEXT NOT NULL,
      approved TINYINT(1) DEFAULT 0,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    `CREATE TABLE IF NOT EXISTS banquet_requests (
      id INT AUTO_INCREMENT PRIMARY KEY,
      contact_name VARCHAR(255) NOT NULL,
      contact_phone VARCHAR(50) NOT NULL,
      event_type VARCHAR(100),
      package_name VARCHAR(100),
      guests_count INT,
      event_date VARCHAR(20),
      extra_services JSON,
      estimated_total INT,
      comment TEXT,
      status VARCHAR(50) DEFAULT 'new',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    `CREATE TABLE IF NOT EXISTS promotions (
      id INT AUTO_INCREMENT PRIMARY KEY,
      title VARCHAR(255) NOT NULL,
      description TEXT,
      discount_text VARCHAR(100),
      expires_at DATETIME,
      is_active TINYINT(1) DEFAULT 1,
      sort_order INT DEFAULT 0,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    `CREATE TABLE IF NOT EXISTS gallery (
      id INT AUTO_INCREMENT PRIMARY KEY,
      url TEXT NOT NULL,
      caption VARCHAR(255),
      category VARCHAR(50) DEFAULT 'general',
      sort_order INT DEFAULT 0,
      is_active TINYINT(1) DEFAULT 1,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

    `CREATE TABLE IF NOT EXISTS settings (
      id INT AUTO_INCREMENT PRIMARY KEY,
      \`key\` VARCHAR(100) NOT NULL UNIQUE,
      \`value\` TEXT,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
  ];

  for (const sql of tables) {
    await pool.execute(sql);
  }

  // Seed default settings
  const defaults = [
    ['telegram_bot_token', ''],
    ['telegram_chat_id', ''],
    ['site_phone', '+7 (925) 767-77-78'],
    ['site_address', 'Московская обл., Химки, ул. Некрасова 15'],
  ];
  for (const [key, value] of defaults) {
    await pool.execute(
      'INSERT INTO settings (`key`,`value`) VALUES (?,?) ON DUPLICATE KEY UPDATE `key`=`key`',
      [key, value]
    );
  }

  res.json({ ok: true, message: 'Все таблицы созданы!' });
}));

// ── SPA fallback ───────────────────────────────────────────────────────────────
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`🚀 Сервер запущен на порту ${PORT}`);
  console.log(`📊 Режим: ${process.env.NODE_ENV || 'development'}`);
});
