-- ============================================================
-- БАЗА ДАННЫХ: Кафе «Соль и Перец»
-- MySQL / MariaDB — REG.RU хостинг
-- 
-- Запустить через phpMyAdmin:
--   1. Войдите в phpMyAdmin на REG.RU
--   2. Выберите базу u3471617_solperets
--   3. Вкладка «SQL» → вставьте этот файл → «Выполнить»
-- ============================================================

SET NAMES utf8mb4;
SET CHARACTER SET utf8mb4;

-- Меню
CREATE TABLE IF NOT EXISTS `menu_items` (
  `id`              INT AUTO_INCREMENT PRIMARY KEY,
  `name`            VARCHAR(255) NOT NULL,
  `description`     TEXT,
  `price`           INT NOT NULL,
  `category`        VARCHAR(100) NOT NULL,
  `image_url`       TEXT,
  `calories`        INT DEFAULT NULL,
  `cook_time`       INT DEFAULT NULL,
  `is_gluten_free`  TINYINT(1) DEFAULT 0,
  `is_lactose_free` TINYINT(1) DEFAULT 0,
  `is_bar`          TINYINT(1) DEFAULT 0,
  `is_active`       TINYINT(1) DEFAULT 1,
  `is_special`      TINYINT(1) DEFAULT 0,
  `original_price`  INT DEFAULT NULL,
  `sort_order`      INT DEFAULT 0,
  `created_at`      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Заказы
CREATE TABLE IF NOT EXISTS `orders` (
  `id`               INT AUTO_INCREMENT PRIMARY KEY,
  `customer_name`    VARCHAR(255) NOT NULL,
  `customer_phone`   VARCHAR(50) NOT NULL,
  `delivery_address` TEXT,
  `comment`          TEXT,
  `items`            JSON NOT NULL,
  `total_amount`     INT NOT NULL,
  `status`           VARCHAR(50) DEFAULT 'new',
  `created_at`       TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Бронирования
CREATE TABLE IF NOT EXISTS `reservations` (
  `id`           INT AUTO_INCREMENT PRIMARY KEY,
  `guest_name`   VARCHAR(255) NOT NULL,
  `guest_phone`  VARCHAR(50) NOT NULL,
  `date`         VARCHAR(20) NOT NULL,
  `time`         VARCHAR(10) NOT NULL,
  `guests_count` INT DEFAULT 2,
  `table_number` INT DEFAULT NULL,
  `status`       VARCHAR(50) DEFAULT 'pending',
  `created_at`   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Отзывы
CREATE TABLE IF NOT EXISTS `reviews` (
  `id`          INT AUTO_INCREMENT PRIMARY KEY,
  `author_name` VARCHAR(255) NOT NULL,
  `rating`      INT NOT NULL CHECK (`rating` BETWEEN 1 AND 5),
  `text`        TEXT NOT NULL,
  `approved`    TINYINT(1) DEFAULT 0,
  `created_at`  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Банкеты
CREATE TABLE IF NOT EXISTS `banquet_requests` (
  `id`              INT AUTO_INCREMENT PRIMARY KEY,
  `contact_name`    VARCHAR(255) NOT NULL,
  `contact_phone`   VARCHAR(50) NOT NULL,
  `event_type`      VARCHAR(100) DEFAULT NULL,
  `package_name`    VARCHAR(100) DEFAULT NULL,
  `guests_count`    INT DEFAULT NULL,
  `event_date`      VARCHAR(20) DEFAULT NULL,
  `extra_services`  JSON,
  `estimated_total` INT DEFAULT 0,
  `comment`         TEXT,
  `status`          VARCHAR(50) DEFAULT 'new',
  `created_at`      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Акции
CREATE TABLE IF NOT EXISTS `promotions` (
  `id`            INT AUTO_INCREMENT PRIMARY KEY,
  `title`         VARCHAR(255) NOT NULL,
  `description`   TEXT,
  `discount_text` VARCHAR(100),
  `expires_at`    DATETIME DEFAULT NULL,
  `is_active`     TINYINT(1) DEFAULT 1,
  `sort_order`    INT DEFAULT 0,
  `created_at`    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Галерея
CREATE TABLE IF NOT EXISTS `gallery` (
  `id`         INT AUTO_INCREMENT PRIMARY KEY,
  `url`        TEXT NOT NULL,
  `caption`    VARCHAR(255),
  `category`   VARCHAR(50) DEFAULT 'general',
  `sort_order` INT DEFAULT 0,
  `is_active`  TINYINT(1) DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Настройки
CREATE TABLE IF NOT EXISTS `settings` (
  `id`         INT AUTO_INCREMENT PRIMARY KEY,
  `key`        VARCHAR(100) NOT NULL UNIQUE,
  `value`      TEXT,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Начальные настройки
INSERT INTO `settings` (`key`, `value`) VALUES
  ('telegram_bot_token', ''),
  ('telegram_chat_id', ''),
  ('site_phone', '+7 (925) 767-77-78'),
  ('site_address', 'Московская обл., Химки, ул. Некрасова 15')
ON DUPLICATE KEY UPDATE `key` = `key`;

-- Начальные акции
INSERT INTO `promotions` (`title`, `description`, `discount_text`, `expires_at`, `is_active`, `sort_order`) VALUES
  ('Счастливые часы', 'С 12:00 до 16:00 скидка 20% на все горячие блюда и супы', '-20%', '2025-12-31 23:59:59', 1, 1),
  ('Шашлык-пати в выходные', 'По пятницам и субботам — шашлык ассорти микс за 3500₽ вместо 4500₽', '-1000₽', '2025-12-31 23:59:59', 1, 2),
  ('Бизнес-ланч', 'Суп + горячее + напиток всего за 490₽. Ежедневно с 12:00 до 15:00', '490₽', '2025-12-31 23:59:59', 1, 3)
ON DUPLICATE KEY UPDATE `id` = `id`;

-- Галерея
INSERT INTO `gallery` (`url`, `caption`, `category`, `sort_order`, `is_active`) VALUES
  ('/images/gallery-1.jpg', 'Уютный зал кафе', 'interior', 1, 1),
  ('/images/gallery-2.jpg', 'Шашлык на мангале', 'food', 2, 1),
  ('/images/gallery-3.jpg', 'День рождения в нашем зале', 'events', 3, 1),
  ('/images/gallery-4.jpg', 'Шах-плов', 'food', 4, 1),
  ('/images/gallery-5.jpg', 'Наш бар', 'bar', 5, 1),
  ('/images/gallery-6.jpg', 'Банкетный зал', 'events', 6, 1),
  ('/images/interior.jpg', 'Интерьер ресторана', 'interior', 7, 1),
  ('/images/banquet.jpg', 'Банкет', 'events', 8, 1)
ON DUPLICATE KEY UPDATE `id` = `id`;
